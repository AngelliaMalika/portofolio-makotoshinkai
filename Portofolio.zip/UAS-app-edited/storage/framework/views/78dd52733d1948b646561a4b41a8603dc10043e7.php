<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link href="https://fonts.googleapis.com/css?family=Lato:100,300,300i,400&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Lato', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #f0f2f5;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .profile-header {
            text-align: center;
        }

        .profile-header h1 {
            margin: 10px 0;
            font-size: 1.5em;
        }

        .profile-header p {
            color: gray;
        }

        .profile-details {
            margin-top: 20px;
        }

        .profile-details label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }

        .profile-details .input-group {
            margin-top: 5px;
            display: flex;
            align-items: center;
        }

        .profile-details input {
            width: calc(100% - 80px); /* Adjust width to accommodate the button */
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: inline-block;
        }

        .profile-details .btn-edit {
            margin-left: 10px;
        }

        .profile-details button {
            margin-top: 20px;
            padding: 10px;
            width: 100%;
            background-color: #71ADDC;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .profile-details button:hover {
            background-color: #5d9ccc;
        }

        .btn-back,
        .btn-logout {
            margin-top: 10px;
            padding: 10px;
            width: 100%;
            background-color: #5d9ccc;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            display: block;
            text-decoration: none;
        }

        .btn-back:hover,
        .btn-logout:hover {
            background-color: #e53935;
        }
    </style>
    <script>
        let editableField = null;

        function enableField(fieldId) {
            document.getElementById(fieldId).readOnly = false;
            document.getElementById("saveBtn").style.display = "block";
            editableField = fieldId;
        }

        function editName() {
            enableField("name");
        }

        function editUsername() {
            enableField("username");
        }

        function editPassword() {
            enableField("password");
        }

        function saveInfo() {
            document.getElementById('profileForm').submit();
        }

        function goBack() {
            window.location.href = "<?php echo e(url('core')); ?>";
        }

        function logout(event) {
            event.preventDefault();
            document.getElementById('logout-form').submit();
        }
    </script>
</head>

<body>
    <div class="container">
        <div class="profile-header">
            <h1 id="displayName"><?php echo e($user->name); ?></h1>
            <p id="displayUsername"><?php echo e('@' . $user->username); ?></p>
        </div>
        <div class="profile-details">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <form id="profileForm" action="<?php echo e(route('profile.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Nama</label>
                    <div class="input-group">
                        <input type="text" id="name" name="name" value="<?php echo e($user->name); ?>" readonly class="form-control">
                        <div class="input-group-append">
                            <button class="btn btn-outline-primary btn-edit" type="button" onclick="editName()">Ubah</button>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="username">Nama Pengguna</label>
                    <div class="input-group">
                        <input type="text" id="username" name="username" value="<?php echo e($user->username); ?>" readonly class="form-control">
                        <div class="input-group-append">
                            <button class="btn btn-outline-primary btn-edit" type="button" onclick="editUsername()">Ubah</button>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Kata Sandi</label>
                    <div class="input-group">
                        <input type="password" id="password" name="password" placeholder="Isi jika ingin mengganti" readonly class="form-control">
                        <div class="input-group-append">
                            <button class="btn btn-outline-primary btn-edit" type="button" onclick="editPassword()">Ubah</button>
                        </div>
                    </div>
                </div>

                <button type="button" id="saveBtn" onclick="saveInfo()" style="display:none;">Simpan Perubahan</button>
            </form>
            <a class="btn-back" href="<?php echo e(url('core')); ?>">Kembali</a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
            <button type="button" class="btn-logout" onclick="logout(event)">Logout</button>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\UAS-app-edited\resources\views/profile.blade.php ENDPATH**/ ?>