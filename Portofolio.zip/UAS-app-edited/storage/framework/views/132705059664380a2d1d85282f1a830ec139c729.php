<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page - Masashi Kishimoto Theme</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 100px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .header {
            background-color:#71ADDC;
            color: #fff;
            padding: 10px;
            text-align: center;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }
        .footer {
            background-color: #71ADDC;
            color: #fff;
            padding: 10px;
            text-align: center;
            border-bottom-left-radius: 8px;
            border-bottom-right-radius: 8px;
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
        }
        .footer a {
            color: #fff;
            text-decoration: none;
            margin-left: 10px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        .form-group input {
            width: calc(100% - 20px);
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background-color: #71ADDC;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }
        .decoration {
            text-align: center;
            margin-top: 20px;
        }
        .decoration img {
            max-width: 100%;
            border-radius: 8px;
            box-shadow: #71ADDC;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Masashi Kishimoto Theme Register</h2>
        </div>
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="password_confirmation">Confirm Password:</label>
                <input type="password" id="password_confirmation" name="password_confirmation" required>
            </div>
            <div class="form-group">
                <button type="submit">Register</button>
            </div>
        </form>
        <a href="<?php echo e(route('login')); ?>">Sudah punya akun? Masuk di sini.</a>
        <div class="footer">
            &copy; 2024 Masashi Kishimoto Fan Page
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\UAS-app-edited\resources\views/register.blade.php ENDPATH**/ ?>