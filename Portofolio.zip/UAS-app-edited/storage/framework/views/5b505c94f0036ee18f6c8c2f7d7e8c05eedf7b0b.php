<!DOCTYPE html>
<html>

<head>
    <title>Portofolio Makoto Shinkai</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style_web.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsif_disp.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Lato:100,300,300i,400&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        /* Style for popup forms */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 400px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            margin-bottom: 5px;
            display: block;
        }

        .form-group input,
        .form-group textarea {
            width: calc(100% - 20px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group button {
            width: 100%;
            padding: 10px;
            background-color: #71ADDC;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #5a9ac6;
        }

        .message-container {
            margin-top: 20px;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .message-container .message {
            margin-bottom: 15px;
            padding: 10px;
            border-bottom: 1px solid #eee;
        }

        .message-container .message img {
            border-radius: 50%;
            width: 40px;
            height: 40px;
            object-fit: cover;
            vertical-align: middle;
        }

        .message-container .message .username {
            font-weight: bold;
            margin-left: 10px;
        }

        .message-container .message .text {
            margin-top: 5px;
            margin-left: 50px;
        }
    </style>
</head>

<body>

    <header id="header" style="
            background-image: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('<?php echo e(asset('img/bg.jpeg')); ?>');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            height: 100vh;">
        <nav>
            <div class="header-left">
                <img class="logo" src="<?php echo e(asset('img/logo porto.png')); ?>" style="width:5%">
                <h1 class="logo-text">Portofolio of Makoto Shinkai</h1>
            </div>
            <ul>
                <li>
                    <a href="<?php echo e(url('profile')); ?>" class="dropbtn">User</a>
                </li>
            </ul>
        </nav>
        <div class="hero-text-box">
            <h1>Makoto Shinkai. (新海誠) <br>Sutradara, Film Maker, Novelis.</h1>
            <a class="btn btn-full" href="#tentang">Tentang</a>
            <a class="btn btn-ghost" href="#movie">Best Movie</a>
            <a class="btn btn-full" href="#kesuksesan">Riwayat Kesuksesan</a>
            <a class="btn btn-ghost" href="javascript:void(0);" onclick="showLoginForm()">Kirim Pesan</a>
        </div>
    </header>

    <main>
        <div id="content">
            <article id="tentang" class="card">
                <h2>Tentang Makoto Shinkai</h2>
                <img src="<?php echo e(asset('img/tentang.jpeg')); ?>" class="featured-image" alt="tentang">
                <p><strong>Makoto Niitsu </strong>(新津 誠, Niitsu Makoto, lahir 9 Februari 1973), yang dikenal sebagai Makoto Shinkai (新海 誠, Shinkai Makoto), adalah seorang pembuat film dan novelis Jepang. 
                    Ia dikenal karena film animenya yang diproduksi dengan studio CoMix Wave Films .
                    Shinkai memulai karirnya sebagai animator video game bersama Nihon Falcom pada tahun 1996, dan mendapat pengakuan sebagai pembuat film dengan merilis video animasi asli (OVA) She and Her Cat (1999). 
                    Shinkai kemudian merilis OVA fiksi ilmiah Voices of a Distant Star pada tahun 2002 sebagai fitur pertamanya dengan CoMix Wave, dan diikuti dengan film fitur debutnya The Place Promised in Our Early Days (2004).
                    Film-film Shinkai secara konsisten mendapat ulasan yang sangat positif baik dari kritikus maupun penonton, dan ia dianggap sebagai salah satu pembuat film paling sukses secara komersial di Jepang.
                </p>
            </article>

            <article id="kesuksesan" class="card">
                <h2>Riwayat Kesuksesan</h2>
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Makoto_Shinkhai_in_Moscow.JPG/1200px-Makoto_Shinkhai_in_Moscow.JPG" class="featured-image" alt="kesuksesan" width="400" height="500">

                <h3>Universitar Chuo</h3>
                <p><strong><span class="detail">Universitas | 1996</span></strong></p>
                <ol>
                    <li>Sebagai salah satu mahasiswa Sastra Jepang</li>
                </ol>
                
                <h3>Carrier</h3>
                <p><strong><span class="detail"> Perusahaan Produksi Game | 1996</span></strong></p>
                <ol>
                    <li>Karya pertama yaitu She and Her Cat | 1999 </li>
                    <li>She and Her Cat berhasil meraih juara pertama dalam kontes animasi DoGA CG ke-12 | 2000</li>
                </ol>
                <h3></h3>
                <p><strong><span class="detail"> Sutradara dan Animator | 2001 - 2022</span></strong></p>
                <ol>
                    <li>Voices of a Distant Star | 2001 - 2002 </li>
                    <li>Salah satu karya terbaik "The Place Promised in Our Early Days" yang berhasil melambungkan namanya sebagai animator dan sutradara kenamaan Jepang| 2004</li>
                    <li>5 Centimeters Per Second(2007) | 2007</li>
                    <li>Puncak popularitasnya setelah merilis "Your Name (Kimi No Nawa)" | 2016</li>
                </ol>
            </article>

            <article id="movie" class="card">
                <h2>Best Movie</h2>
                <div class="slideshow-container">

                    <div class="slides fade">
                        <div class="numbertext">1 / 8</div>
                        <img src="<?php echo e(asset('img/Screenshot_1.jpeg')); ?>" style="width:100%">
                        <div class="text"><strong>Suzume (2022)</strong></div>
                    </div>

                    <div class="slides fade">
                        <div class="numbertext">2 / 8</div>
                        <img src="<?php echo e(asset('img/Screenshot_2.jpeg')); ?>" style="width:100%">
                        <div class="text"><strong>Your Name (2016)</strong></div>
                    </div>

                    <div class="slides fade">
                        <div class="numbertext">3 / 8</div>
                        <img src="<?php echo e(asset('img/Screenshot_3.jpeg')); ?>" style="width:100%">
                        <div class="text"><strong>Weathering With You (2019)</strong></div>
                    </div>

                    <div class="slides fade">
                        <div class="numbertext">4 / 8</div>
                        <img src="<?php echo e(asset('img/Screenshot_4.jpg')); ?>" style="width:100%">
                        <div class="text"><strong>Voices of a Distant Star (2002)</strong></div>
                    </div>

                    <div class="slides fade">
                        <div class="numbertext">5 / 8</div>
                        <img src="<?php echo e(asset('img/Screenshot_5.jpeg')); ?>" style="width:100%">
                        <div class="text"><strong>The Garden of Words (2013)</strong></div>
                    </div>

                    <div class="slides fade">
                        <div class="numbertext">6 / 8</div>
                        <img src="<?php echo e(asset('img/Screenshot_6.jpeg')); ?>" style="width:100%">
                        <div class="text"><strong>5 Centimeters Per Second (2007)</strong></div>
                    </div>

                    <div class="slides fade">
                        <div class="numbertext">7 / 8</div>
                        <img src="<?php echo e(asset('img/Screenshot_7.jpeg')); ?>" style="width:100%">
                        <div class="text"><strong>The Place Promised in Our Early Days (2004)</strong></div>
                    </div>

                    <div class="slides fade">
                        <div class="numbertext">8 / 8</div>
                        <img src="<?php echo e(asset('img/Screenshot_8.jpeg')); ?>" style="width:100%">
                        <div class="text"><strong>Children Who Chase Lost Voices (2011)</strong></div>
                    </div>

                    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                    <a class="next" onclick="plusSlides(1)">&#10095;</a>
                </div>
                <br>

                <div style="text-align:center">
                    <span class="dot" onclick="currentSlide(1)"></span>
                    <span class="dot" onclick="currentSlide(2)"></span>
                    <span class="dot" onclick="currentSlide(3)"></span>
                    <span class="dot" onclick="currentSlide(4)"></span>
                    <span class="dot" onclick="currentSlide(5)"></span>
                    <span class="dot" onclick="currentSlide(6)"></span>
                    <span class="dot" onclick="currentSlide(7)"></span>
                    <span class="dot" onclick="currentSlide(8)"></span>
                </div>
            </article>

            <article id="pesan" class="card">
                <h2>Pesan Penggemar</h2>
                <div id="fanMessages">
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="message">
                            <h3><?php echo e($message->name); ?></h3>
                            <p><?php echo e($message->message); ?></p>
                            <small><?php echo e($message->created_at); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </article>
        </div>

        <aside>
            <article class="profile card">
                <div class="sidebar">
                    <h2>Profile</h2>
                    <p class="profile-text"><strong></strong>Sutradara, Film Maker, Novelis.</p>
                    <img src="<?php echo e(asset('img/profile.jpeg')); ?>">
                </div>
                <div class="account">
                    <h3>Informasi Lengkap</h3>
                    <table class="center">
                        <tr>
                            <th>Nama</th>
                            <td>:</td>
                            <td>Makoto Niitsu</td>
                        </tr>
                        <tr>
                            <th>Tempat Lahir</th>
                            <td>:</td>
                            <td>Koumi, Jepang</td>
                        </tr>
                        <tr>
                            <th>Tanggal Lahir</th>
                            <td>:</td>
                            <td>09 Februari 1973</td>
                        </tr>
                        <tr>
                            <th>Usia</th>
                            <td>:</td>
                            <td>51 Tahun</td>
                        </tr>
                        <tr>
                            <th>Nama Kana</th>
                            <td>:</td>
                            <td>しんかい まこと</td>
                        </tr>
                        <tr>
                            <th>Jenis Kelamin</th>
                            <td>:</td>
                            <td>Laki-laki</td>
                        </tr>
                        <tr>
                            <th>Kewarganegaraan</th>
                            <td>:</td>
                            <td>Jepang</td>
                        </tr>
                        <tr>
                            <th>Pendidikan Terakhir</th>
                            <td>:</td>
                            <td>Universitas Chuo</td>
                        </tr>
                        <tr>
                            <th>Tahun Aktif</th>
                            <td>:</td>
                            <td>1996 - Sekarang</td>
                        </tr>
                    </table>
                </div>
            </article>
        </aside>

        <aside>
            <article class="profile card">
                <div class="sidebar">
                    <h2>Social Media</h2>
                    <p class="profile-text"><strong>Makoto Shinkai</strong></p>
                    <img src="<?php echo e(asset('img/sosmed.jpeg')); ?>">
                </div>
                <div class="account">
                    <h3>Akun Sosial Media</h3>
                    <table class="center">
                        <tr>
                            <th>
                                <ion-icon name="logo-instagram" size="large"></ion-icon>
                            </th>
                            <td>:</td>
                            <td><a href="https://www.instagram.com/makoto.shinkai/">makoto.shinkai</a></td>
                        </tr>
                        <tr>
                            <th>
                                <ion-icon name="mail-outline" size="large"></ion-icon>
                            </th>
                            <td>:</td>
                            <td>m2shinkai.ig@gmail.com</td>
                        </tr>
                        <tr>
                            <th>
                                <ion-icon name="logo-facebook" size="large"></ion-icon>
                            </th>
                            <td>:</td>
                            <td><a href="https://www.facebook.com/profile.php?id=100072010530221&mibextid=YMEMSu">Makoto Shinkai</a></td>
                        </tr>
                        <tr>
                            <th>
                                <ion-icon name="logo-twitter" size="large"></ion-icon>
                            </th>
                            <td>:</td>
                            <td><a href="https://x.com/makoto.shinkai/">shinkaimakoto</a></td>
                        </tr>
                    </table>
                </div>
            </article>
        </aside>

        <aside id="signature">
            <article id="signature" class="card">
                <div class="signature">
                    <h3>The Artist Signature :</h3>
                    <table class="center">
                        <img src="<?php echo e(asset('img/signature.png')); ?>" class="featured-image" alt="signature" style="width:30%">
                        <p>Makoto Shinkai Signature</p>
                    </table>
                </div>
            </article>
        </aside>

        <aside id="creator1">
            <article id="creator1" class="card"> 
                <div class="creators-container-1">
                    <div class="creator-1">
                        <img src="<?php echo e(asset('img/Angellia.jpg')); ?>" class="featured-image" alt="creator1" style="width:82%">
                        <h3>Website Creator 1</h3>
                        <table class="center">
                            <tr>
                                <th>Nama</th>
                                <td>:</td>
                                <td>Angellia Malika Putri S</td>
                            </tr>
                            <tr>
                                <th>NIM</th>
                                <td>:</td>
                                <td>2203421022</td>
                            </tr>
                            <tr>
                                <th>Kelas</th>
                                <td>:</td>
                                <td>BM4B</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </article>
        </aside>
        
        <aside id="creator2">
            <article id="creator2" class="card"> 
                <div class="creators-container-2">
                    <div class="creator-2">
                        <img src="<?php echo e(asset('img/Bemi.jpg')); ?>" class="featured-image" alt="creator2" style="width:82%">
                        <h3>Website Creator 2</h3>
                        <table class="center">
                            <tr>
                                <th>Nama</th>
                                <td>:</td>
                                <td>Bemi Raihan Rawadi</td>
                            </tr>
                            <tr>
                                <th>NIM</th>
                                <td>:</td>
                                <td>2203421034</td>
                            </tr>
                            <tr>
                                <th>Kelas</th>
                                <td>:</td>
                                <td>BM4B</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </article>
        </aside>

    </main>

    <footer>
        <p>Pemrograman Web dan Data &#169; 2024, Project UTS - Angellia & Bemi</p>
    </footer>

    <div id="loginModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="hideLoginForm()">&times;</span>
            <form action="<?php echo e(route('messages.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Nama:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="message">Pesan:</label>
                    <textarea id="message" name="message" rows="4" required></textarea>
                </div>
                <div class="form-group">
                    <button type="submit">Kirim</button>
                </div>
            </form>
        </div>
    </div>
    
    

    <script>
        function showLoginForm() {
            document.getElementById('loginModal').style.display = 'block';
        }

        function hideLoginForm() {
            document.getElementById('loginModal').style.display = 'none';
        }

        let slideIndex = 1;
        showSlides(slideIndex);

        function plusSlides(n) {
            showSlides(slideIndex += n);
        }

        function currentSlide(n) {
            showSlides(slideIndex = n);
        }

        function showSlides(n) {
            let i;
            let slides = document.getElementsByClassName("slides");
            let dots = document.getElementsByClassName("dot");
            if (n > slides.length) {
                slideIndex = 1
            }
            if (n < 1) {
                slideIndex = slides.length
            }
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slides[slideIndex - 1].style.display = "block";
            dots[slideIndex - 1].className += " active";
        }
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\UAS-app-edited\resources\views/core.blade.php ENDPATH**/ ?>