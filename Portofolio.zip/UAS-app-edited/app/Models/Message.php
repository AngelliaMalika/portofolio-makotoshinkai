<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    use HasFactory;

    // Izinkan mass assignment untuk kolom name dan message
    protected $fillable = ['name', 'message'];
}
