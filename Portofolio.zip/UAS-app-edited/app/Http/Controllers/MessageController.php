<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Message;

class MessageController extends Controller
{
    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'name' => 'required|string|max:255',
            'message' => 'required|string|max:1000',
        ]);

        // Simpan pesan
        Message::create([
            'name' => $request->name,
            'message' => $request->message,
        ]);

        // Redirect atau kirim respon
        return redirect()->route('core')->with('success', 'Pesan berhasil dikirim!');
    }

    public function index()
    {
        // Ambil semua pesan dari database
        $messages = Message::all();

        // Kirim pesan ke tampilan
        return view('core', ['messages' => $messages]);
    }
}
